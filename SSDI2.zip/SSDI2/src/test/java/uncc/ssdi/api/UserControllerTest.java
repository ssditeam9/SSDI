package uncc.ssdi.api;

import static org.junit.Assert.*;

import org.junit.Test;

public class UserControllerTest {

	@Test
	public final void testSignUp() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testSignUpPost() {
		fail("Not yet implemented"); // TODO
	}

}
