package uncc.ssdi.api;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@RunWith(SpringJUnit4ClassRunner.class)
//@WebMvcTest(value = ProductController.class, secure = false)
public class ProductControllerTest2 {
	
	private MockMvc mockMvc;
	
	@InjectMocks
	private ProductController productController;
	
	//Product mockProduct=new Product(1.0,"watch","nice watch",65.23,35.23,2,"89","xyz.com");
	@Before	
	public void setUp() throws Exception{
		mockMvc = MockMvcBuilders.standaloneSetup(productController).build();
	}
	
	@Test
	public void testController() throws Exception{
		mockMvc.perform(MockMvcRequestBuilders.get("/api/DisplayProducts")).andExpect(MockMvcResultMatchers.status().isOk())
		.andExpect(MockMvcResultMatchers.content().string("Hello world"));
	}
	
}
