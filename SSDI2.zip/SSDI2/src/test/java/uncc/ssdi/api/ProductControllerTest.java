package uncc.ssdi.api;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import uncc.ssdi.model.Product;
import uncc.ssdi.service.IProductService;
import uncc.ssdi.service.IProductServiceTest;
import uncc.ssdi.service.ProductService;
import uncc.ssdi.service.ProductServiceTest;

@RestController
public class ProductControllerTest {

	
	@Autowired
	private IProductServiceTest productServiceTest;

	public ProductControllerTest() {
		productServiceTest = new ProductServiceTest();
	}
	
	@Test
	@RequestMapping("/getProdTest")
	    public void getAllProducts() {
	        ModelAndView mav = new ModelAndView("hello");
	        productServiceTest.getAllProducts();
		    //mav.addObject("productList", productList);
	    }

	@Test
	public final void testGetAllProducts() {
		fail("Not yet implemented"); // TODO
	}

}
