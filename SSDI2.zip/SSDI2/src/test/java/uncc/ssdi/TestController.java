package uncc.ssdi;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.setup.StandaloneMockMvcBuilder;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import uncc.ssdi.api.ProductController;
import uncc.ssdi.model.Product;
import uncc.ssdi.service.*;

@RunWith(MockitoJUnitRunner.class)
//@WebMvcTest(value = ProductController.class, secure = false)
public class TestController {
	
	private MockMvc mockMvc;
	
	@Mock
    ProductService productService;
	
	@InjectMocks
	private ProductController productController;
	
	
	/*Product mockProduct=new Product(1.0,"watch","nice watch",65.23,35.23,2,"89","xyz.com");
	@Before
	public void setUp() throws Exception{
		
		//MockitoAnnotations.initMocks(this);
		
		InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        viewResolver.setPrefix("/webapp");
        viewResolver.setSuffix(".jsp");
		mockMvc = MockMvcBuilders.standaloneSetup(productController).build();
	}
	
	@Test
	public void testController() throws Exception{
		ArrayList<Product> products = new ArrayList<Product>();
		Product product1 = new Product();
		product1.setDescription("Sample Description 1");
		Product product2 = new Product();
		product2.setDescription("Sample Description 2");
		products.add(product1);
		products.add(product2);
		Mockito.when(productService.getAllProducts()).thenReturn(products);
		ModelAndView mav = productController.hello(null, "SampleName");
		
		ArrayList<Product> productsreturned = new ArrayList<Product>();
		productsreturned=(ArrayList<Product>)mav.getModel().get("productList");
		assertEquals(2,productsreturned.size());
		assertEquals("Sample Description 1",productsreturned.get(0).getDescription());
		assertEquals("SampleName", mav.getModel().get("name").toString());
	}
	*/
	

	
	

}
