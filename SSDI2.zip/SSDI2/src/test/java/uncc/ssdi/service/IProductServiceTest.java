package uncc.ssdi.service;

public interface IProductServiceTest {

	public void getAllProducts();
	public void test(long abc);
}
