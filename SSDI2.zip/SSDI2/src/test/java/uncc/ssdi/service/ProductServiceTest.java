package uncc.ssdi.service;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import uncc.ssdi.dao.ProductRepository;
import uncc.ssdi.model.IProduct;
import uncc.ssdi.model.Product;

@Service
public class ProductServiceTest implements IProductServiceTest {

	@Autowired
	private ProductRepository ProductRepository;
	
	@Test
	public void getAllProducts(){		
		List<Product> list = new ArrayList<>();
		ProductRepository.findAll().forEach(e -> list.add(e));
		assertEquals(list.size(), 6);
		System.out.println("Assertion in Product Service complete");
	}
	
	public void test(long lg) {
		System.out.println("**********inside test in service");
		boolean present = ProductRepository.existsById(lg);
		 System.out.println("**************8"+present);
	}
}
